package com.jdbc.finance_tracker;

/**
 * Hello world!
 *
 */


import ui.UI;

public class App {
    public static void main(String[] args) {
        System.out.println("Welcome to the Personal Finance Tracker!");
        UI.start(); // Start the UI to interact with the user
    }
}
